import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-4WQ5ITNC.js";
import "./chunk-P4WTAAAO.js";
import "./chunk-OQ4VTOMY.js";
import "./chunk-75MT3XXZ.js";
import "./chunk-UKGXAR6E.js";
import "./chunk-6Y7T4UFD.js";
import "./chunk-QPEXF2MT.js";
import "./chunk-UBGM4B6N.js";
import "./chunk-LL5RF35Z.js";
import "./chunk-733PALXA.js";
import "./chunk-S35MAB2V.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
