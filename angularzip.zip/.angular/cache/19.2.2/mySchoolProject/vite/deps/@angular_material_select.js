import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-ZHOYL27Q.js";
import "./chunk-LTDMRT3X.js";
import "./chunk-HSLEQ7BX.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-4MSFZOU4.js";
import "./chunk-OJBAHBQA.js";
import "./chunk-HNPMCUUM.js";
import "./chunk-PKDHZ2AZ.js";
import "./chunk-5ZZ2CCZX.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-75MT3XXZ.js";
import "./chunk-UKGXAR6E.js";
import "./chunk-6Y7T4UFD.js";
import "./chunk-QPEXF2MT.js";
import "./chunk-UBGM4B6N.js";
import "./chunk-LL5RF35Z.js";
import "./chunk-733PALXA.js";
import "./chunk-S35MAB2V.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
