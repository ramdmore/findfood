import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MessOwnerDetailsService {

  constructor( private http: HttpClient) { }

  myMessPostDetailsApiUrls = 'https://findfood-ashen.vercel.app/api/user/messData';

  postMessDetails(messObj:any){
    return this.http.post(this.myMessPostDetailsApiUrls, messObj)
  }
}
