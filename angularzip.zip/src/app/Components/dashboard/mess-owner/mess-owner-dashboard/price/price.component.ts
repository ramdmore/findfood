import { Component } from '@angular/core';

@Component({
  selector: 'app-price',
  standalone: false,
  templateUrl: './price.component.html',
  styleUrl: './price.component.css'
})
export class PriceComponent {

}
