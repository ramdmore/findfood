import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CredentialsService } from '../../Shared/Services/credentials.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  captchaText: string = '';

  constructor(private fb: FormBuilder, private httpService: CredentialsService, private http: HttpClient, private router: Router) {}

  ngOnInit() {
    this.initializeForm();
    this.generateCaptcha();
  }

  // Initialize form with validation
  initializeForm() {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      captcha: ['', Validators.required]
    });
  }

  // Generate random CAPTCHA
  generateCaptcha() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    this.captchaText = Array.from({ length: 6 }, () =>
      characters.charAt(Math.floor(Math.random() * characters.length))
    ).join('');
  }

  // Handle form submission
  onSubmit() {
    if (this.loginForm.invalid) {
      alert('Please fill all fields correctly.');
      return;
    }

    if (this.loginForm.value.captcha !== this.captchaText) {
      alert('Invalid CAPTCHA. Try again.');
      this.generateCaptcha();
      this.loginForm.controls['captcha'].reset();
      return;
    }
    console.log(this.loginForm.value);

    this.httpService.postLogIn(this.loginForm.value).subscribe({
      next :(resp:any)=>{
        console.log(resp);
        
        localStorage.setItem('userId',resp.userId)
        localStorage.setItem('role',resp.role)

        this.http.get('https://findfood-ashen.vercel.app/api/user/messFormRendering',{
          withCredentials : true
        }).subscribe({
          next:(_resp:any)=>{
            if(_resp.success === true){
              this.router.navigate(['messdetail'])
            }
          },  
          error:(_err:any)=>{
            if(_err.error.success === false){
              this.router.navigate(['messownerdashboard'])
            }
          }
        })

        console.log(resp);
        alert('Login successful!');
      }
    })
    
  }

}
